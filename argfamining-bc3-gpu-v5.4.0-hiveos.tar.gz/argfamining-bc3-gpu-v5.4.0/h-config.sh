#!/usr/bin/env bash
# ArgfaMining BC3 GPU miner (AURORA-FUSION v5.4.0) - HiveOS h-config.sh
# Generates the miner config from the flight sheet. HiveOS provides in the environment:
#   CUSTOM_TEMPLATE   -> wallet (with %WAL% already substituted by HiveOS)
#   CUSTOM_USER_CONFIG-> "Extra config arguments" (--region/--mode go here), e.g.: --region in --mode prop
#   WORKER_NAME       -> rig name
# We do NOT use CUSTOM_CONFIG_FILENAME: on Filipao's HiveOS it arrived EMPTY (2026-07-24) →
# "cat > '': No such file or directory" and the WAL was never passed. See below.
[[ -z $CUSTOM_TEMPLATE ]] && echo "h-config: CUSTOM_TEMPLATE is empty" && return 1

# The template may come as "wallet" or "wallet.worker"; we take only the wallet.
WAL=$(echo "$CUSTOM_TEMPLATE" | cut -d. -f1)
WORKER="${WORKER_NAME:-$(hostname)}"

MINER_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN="$MINER_DIR/argfamining-bc3-gpu"

# ── Wallet check (v5.3.0) ────────────────────────────────────────────────────
# A rig mining to an invalid address works for nothing: the pool counts the
# shares, but when the block matures the node rejects the address and the reward
# cannot be delivered. Better to stop here than to burn hours of hashrate.

# Case 1: the template was never substituted. This is a flight sheet problem,
# not a typo, so it gets its own hint. Seen for real in the pool: a rig mining
# under the literal username "%WAL%".
if [[ "$WAL" == *%* ]]; then
    echo "h-config: the wallet arrived literally as '$WAL' — HiveOS did not substitute the template."
    echo "h-config: check the 'Wallet and worker template' field of your flight sheet."
    return 1
fi

# Case 2: real checksum check. The binary is the single source of truth
# (core/address.cpp) — we do NOT reimplement bech32 in bash, or it would drift.
# libcudart.so.13 ships in this folder, so the loader needs it on the path even
# for --check-address, which exits before touching any GPU.
if [[ -x "$BIN" ]]; then
    LD_LIBRARY_PATH="$MINER_DIR:${LD_LIBRARY_PATH:-}" "$BIN" --check-address "$WAL" >/dev/null 2>&1
    rc=$?
    if [[ $rc -eq 1 ]]; then
        echo "h-config: '$WAL' is not a valid BC3 address (bad format or checksum)."
        echo "h-config: copy it straight from your wallet — one wrong character and you mine for nothing."
        return 1
    elif [[ $rc -ne 0 ]]; then
        # Anything other than 0/1 means the CHECK failed, not the address (missing
        # library, wrong arch...). Never block a rig because our own tool broke:
        # let it through — the miner runs the same check again at startup.
        echo "h-config: could not run the address check (exit $rc); continuing, the miner will verify at startup."
    fi
fi

# Config goes to a FIXED path inside the miner's own dir. ${BASH_SOURCE[0]} gives the path
# of THIS script even when HiveOS 'source's it instead of executing it directly ($0 would
# fail there). h-run.sh reads from the same place (./miner-config.env), so we do not
# depend on HiveOS.
CONF="$MINER_DIR/miner-config.env"
cat > "$CONF" <<EOF
WAL="$WAL"
WORKER="$WORKER"
USER_CONFIG="$CUSTOM_USER_CONFIG"
EOF
