#!/usr/bin/env bash
# ArgfaMining BC3 GPU miner (AURORA-FUSION v5.4.0) - HiveOS h-run.sh - starts the miner.
cd "$(dirname "$0")"
# Config written by h-config.sh at a fixed path in the miner dir (does NOT depend on
# CUSTOM_CONFIG_FILENAME, which HiveOS may not export — see h-config.sh).
[[ -f ./miner-config.env ]] && . ./miner-config.env

# libcudart.so.13 is bundled in this folder (the binary links it dynamically);
# we add it to LD_LIBRARY_PATH so we do not depend on the rig's CUDA Toolkit.
export LD_LIBRARY_PATH="$(pwd):${LD_LIBRARY_PATH:-}"

# Mines EXCLUSIVELY to the ArgfaMining pool (region-locked; endpoints XOR-obfuscated in the
# binary). Native MULTI-GPU: uses ALL supported cards in the rig — NVIDIA (sm_75+, CUDA)
# and AMD (OpenCL, if the rig has the ICD), even mixed (v5.3.0: unified enumeration,
# one Context per card) — with a single process, single worker, summed hashrate. region/mode
# come from USER_CONFIG ("Extra config arguments": --region latam|usa|eu|in --mode solo|prop).
# If not specified, the binary defaults to region=usa / mode=prop.
exec ./argfamining-bc3-gpu \
  --wallet "$WAL" \
  --worker "$WORKER" \
  $USER_CONFIG 2>&1 | tee "${CUSTOM_LOG_BASENAME:-./miner}.log"
