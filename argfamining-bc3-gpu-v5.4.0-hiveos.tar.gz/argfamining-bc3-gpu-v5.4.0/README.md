# ArgfaMining BC3 (BitcoinIII) GPU Miner — HiveOS — v5.4.0 AURORA-FUSION

> **New in v5.4.0 — version parity with Windows.** v5.4.0 fixes a Windows-GUI-only
> issue (the intensity slider could silently revert while mining). The headless
> CLI used by HiveOS has no such surface: **zero functional changes** vs v5.3.0.
> Published so every platform reports the same version.

**⚠️ CLOSED SOURCE — ArgfaMining team only. Do not distribute the source code.**

Official BC3 (SHA3-256t) miner packaged as a **HiveOS Custom Miner**. It wraps the
**Linux headless v5.4.0** binary with the 4 HiveOS integration scripts. Native
**multi-GPU** (uses every supported card in the rig with a single process). Mines
**exclusively** to the ArgfaMining pool.

> **⚠️ Package status:** the `argfamining-bc3-gpu-v5.4.0-hiveos.tar.gz` does **not
> exist yet** — the Linux v5.4.0 build is still pending. It is generated with
> `miners/tools/gpu tools/package-hiveos.sh 5.4.0` once the binary is compiled
> (see [Reproduce](#reproduce)). These scripts are already finished and versioned.

## New in v5.3.0 — mixed NVIDIA+AMD rigs (dual backend)

Up to v5.1.0 the backend selection was process-global: with an NVIDIA card present,
CUDA was chosen and any AMD cards in the same rig were left out. v5.3.0 brings
**unified GPU enumeration** (CUDA first, then non-NVIDIA OpenCL), **CUDA and OpenCL
contexts coexisting in the same process** (one Context per card), a **per-backend**
boot self-test (on a mixed rig the log shows `kernel self-test (CUDA)` **and**
`kernel self-test (OpenCL)`), and iGPUs/APUs are excluded from the default device
selection (falling back to all devices if the rig is APU-only). Bonus: AMD multi-GPU
now uses all of its devices (previously only one).

**On HiveOS this applies if the rig has the AMD ICD** (AMD image or an installed
OpenCL runtime): a rig with mixed NVIDIA+AMD cards mines with every card under a
single process and a single worker. On NVIDIA-only rigs the behavior is identical to
v5.1.0. Everything else (SHA3-256t kernel, stratum, auto-tune, regions) is unchanged.

## v5.1.0 history — fourth endpoint INDIA/Mumbai

v5.1.0 added the fourth regional PoP: **INDIA · Mumbai** (`--region in`,
`stratum-in.argfamining.com`, AWS `ap-south-1`).

## Installing on a HiveOS rig

1. Host the `argfamining-bc3-gpu-v5.4.0-hiveos.tar.gz` package at any reachable URL.
   In HiveOS create a **Flight Sheet** with:
   - **Coin**: `Custom`
   - **Wallet**: your BC3 address (`1…`/`3…`/`bc1…`)
   - **Miner**: `Custom`
   - **Installation URL**: the URL of the `.tar.gz`
   - **Hash algorithm**: leave it at `----`. BC3 uses SHA3-256t, but that value **is
     not in the HiveOS dropdown** — and it doesn't need to be: this is a custom
     miner, the algorithm is hardcoded in the binary and HiveOS **never reads that
     field** (`h-run.sh` only passes `--wallet`, `--worker` and the extra args;
     `CUSTOM_ALGO` is not used in any script). The dashboard still reports
     `sha3-256t`, because `h-stats.sh` emits it. Do **not** pick `sha3d` or
     `sha256t`: those are different algorithms.
2. In the miner's **Extra config arguments**, pick region and mode:
   ```
   --region in --mode prop
   ```
   - **region**: `latam` (Venezuela) · `usa` (Virginia) · `eu` (Frankfurt) · `in` (Mumbai)
   - **mode**: `solo` (99% of the block, 1% fee) · `prop` (share-based split)
   - If omitted: defaults to `--region usa --mode prop`.
   - Other optional flags: `--intensity 22..31`, `--devices 0,1` (pick specific
     cards — unified v5.3.0 index: CUDA first, then non-NVIDIA OpenCL).
3. Apply the flight sheet. HiveOS installs the package and starts mining on **every
   supported GPU** automatically.

## Notes

- **Requirements**: NVIDIA **sm_75+** (Turing RTX 20xx → Ampere → Ada → Blackwell RTX 50xx).
  **AMD (OpenCL) supported if the rig has the ICD** — with v5.3.0 even mixed with
  NVIDIA in the same rig. `libcudart.so.12` is **bundled** in the package (no
  dependency on the rig's CUDA Toolkit).
- **Pool-locked**: the public build mines only to ArgfaMining — the flight sheet's
  Pool URL is ignored; the region selects the endpoint (the hosts are XOR-obfuscated
  inside the binary).
- **Self-test**: on startup the kernel self-test runs (Tier 1 FIPS-202 + Tier 2
  CPU==GPU), **per backend** on mixed rigs (CUDA and OpenCL separately). If it
  prints `FAIL`, it does not mine. `verify_fail` must stay at 0. A GPU whose backend
  failed to initialize is disabled.
- **Stats**: hashrate + accepted/rejected shares are reported to the HiveOS
  dashboard via `h-stats.sh` (temps/fans come from `nvidia-smi` — on AMD cards
  thermal telemetry is not reported yet; the hashrate is, because the binary
  aggregates it).

## Package contents

`h-manifest.conf` · `h-config.sh` · `h-run.sh` · `h-stats.sh` · `argfamining-bc3-gpu` (Linux x64 binary) · `libcudart.so.12`

## Reproduce

**Pending for this version** — the order is:

1. Compile the portable Linux v5.3.0 binary (glibc 2.31 — HiveOS is Ubuntu 20.04,
   see `FIX-hiveos-glibc.md`): in `../../linux/development/v5.3.0/`,
   `docker build -f Dockerfile.hiveos --target export --output type=local,dest=./out-hiveos .`
   (does NOT need a GPU).
2. Validate on a real GPU: self-test `PASS`, `verify_fail=0`, accepted shares.
3. Package: `miners/tools/gpu tools/package-hiveos.sh 5.4.0` (on WSL2/Linux) →
   leaves the `.tar.gz` + sha256 in `HiveOS/final release/v5.3.0/`.
4. Publish to `downloads/bc3-gpu/v5.3.0/` on the server.

Support: <https://discord.gg/nZTu2QC2YC>
